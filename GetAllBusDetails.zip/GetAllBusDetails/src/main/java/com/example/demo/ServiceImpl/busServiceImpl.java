package com.example.demo.ServiceImpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.bus;
import com.example.demo.Repository.busRepository;
import com.example.demo.entity.bus;
import com.example.demo.service.busService;

import jakarta.persistence.EntityNotFoundException;

import java.util.List;
import java.util.Optional;

@Service
public class busServiceImpl implements busService {

    private final busRepository busRepository;

    @Autowired
    public busServiceImpl(busRepository busRepository) {
        this.busRepository = busRepository;
    }

    @Override
    public List<bus> getAllBusDetails() {
        return busRepository.findAll();
    }

    @Override
    public bus addBusDetails(bus details) {
        return busRepository.save(details);
    }

    	
	}

