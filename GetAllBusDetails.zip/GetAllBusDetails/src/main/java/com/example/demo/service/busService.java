package com.example.demo.service;

import java.util.List;
import com.example.demo.entity.bus;

public interface busService {
	

	public List<bus> getAllBusDetails();

	public bus addBusDetails(bus details);

	
	

}
