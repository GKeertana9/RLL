package com.busManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedbusDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedbusDemoApplication.class, args);
	}

}
