package com.busManagement.service;

import java.util.List;

import com.busManagement.entity.Admin;
import com.busManagement.entity.BusDetails;
import com.busManagement.entity.Passenger;
import com.busManagement.entity.User;
import com.busManagement.utils.AdminAuth;

public interface AdminService {
	public Admin addAdmin(Admin admin); //adding admin

	
	public Admin adminLogin(AdminAuth auth);

    public BusDetails addBusDetails(BusDetails details);

	
	



	
	

	

}
