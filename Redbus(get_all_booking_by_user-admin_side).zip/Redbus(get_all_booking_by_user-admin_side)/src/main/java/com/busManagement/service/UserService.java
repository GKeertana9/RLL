package com.busManagement.service;

import java.util.List;

import com.busManagement.entity.BookingDetails;
import com.busManagement.entity.BusDetails;
import com.busManagement.entity.Passenger;
import com.busManagement.entity.User;
import com.busManagement.utils.UserAuth;

public interface UserService {
	public User addUser(User user);
   public User userLogin(UserAuth auth);

	public BookingDetails addBooking(BookingDetails booking, Integer userId, Integer busNumber);

	

	
	
	

	
}
