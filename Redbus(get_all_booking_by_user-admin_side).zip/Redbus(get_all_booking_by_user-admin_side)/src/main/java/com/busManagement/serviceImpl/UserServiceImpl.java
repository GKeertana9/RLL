package com.busManagement.serviceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.busManagement.Dao.*;
import com.busManagement.entity.BookingDetails;
import com.busManagement.entity.BusDetails;
import com.busManagement.entity.Passenger;
import com.busManagement.entity.User;
import com.busManagement.exception.BusDetailsNotFoundException;
import com.busManagement.exception.NullBusDetailsException;
import com.busManagement.exception.NullUserException;
import com.busManagement.exception.PassengerNotFoundException;
import com.busManagement.exception.UserAlreadyExistException;
import com.busManagement.exception.UserDoesnotExistException;
import com.busManagement.service.UserService;
import com.busManagement.utils.UserAuth;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;

	@Autowired
	BusDetailsDao busDao;

	@Autowired
	BookingDetailsDao bookingDao;
	
	@Autowired
	PassengerDao passengerDao;

	@Override
	public User addUser(User user) {

		if (user == null)
			throw new NullUserException("Please Enter Data");
		Integer userId = (int) ((Math.random() * 900) + 100);
		user.setUserId(userId);
		Optional<User> checkUser = userDao.findById(user.getUserId());
		if (checkUser.isPresent())
			throw new UserAlreadyExistException("user already exists");

		userDao.save(user);
		System.out.println("user Added Succesfully");
		return user;

	}

	
	
	
	
	@Override
	public User userLogin(UserAuth auth) {
		if (auth == null) {
			throw new NullUserException("Please Enter Data");
		}
		Optional<User> user = userDao.findById(auth.getUserId());
		if (user.isPresent()) {
			if (user.get().getUserId() == auth.getUserId() && user.get().getPassword().equals(auth.getPassword())) {
				return user.get();
			} else {
				throw new UserDoesnotExistException("Invalid login ID or Password");
			}
			
		} else {
			throw new UserDoesnotExistException("Sorry! User not found");
		}
	}

	
	@Override
	public BookingDetails addBooking(BookingDetails booking, Integer userId, Integer busNumber) {
		Optional<User> user = userDao.findById(userId);
		Optional<BusDetails> bus = busDao.findById(busNumber);
		if (!user.isPresent()) {
			throw new UserDoesnotExistException("Sorry! user id not found");
		}
		if (!bus.isPresent()) {
			throw new BusDetailsNotFoundException("Oops!! bus details not found");
		}
		Integer bookingId = (int) ((Math.random() * 9000) + 1000);
		booking.setBookingId(bookingId);
		booking.setOwnerId(userId);
		booking.setBusNumber(busNumber);
		booking.setBookingDate(LocalDate.now().toString());
		booking.setBookingTime(LocalTime.now().toString().substring(0, 5));
		booking.setTotalCost(bus.get().getCost() * booking.getPassengers().size());
		List<BookingDetails> bookingList = user.get().getBookingDetails();
		bookingList.add(booking);
		user.get().setBookingDetails(bookingList);
		//updateUser(user.get());
		return bookingDao.getById(bookingId);
	}
     
	


	
	
    
	


}
