package com.example.demo;
import com.example.demo.entity.Admin;
import com.example.demo.repository.AdminRepository;
import com.example.demo.service.AdminService;
import com.example.demo.serviceImpl.AdminServiceImpl;
import com.example.demo.utills.AdminAuth;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class AdminTest {

    @Mock
    private AdminRepository adminRepository;

    private AdminService adminService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
        adminService = new AdminServiceImpl(adminRepository);
    }

    @Test
    public void testSaveAdmin() {
        // Create a sample admin
        Admin admin = new Admin();
        admin.setAdminName("Admin");
        admin.setPassword("admin@123");

        
        when(adminRepository.save(admin)).thenReturn(admin);

        // Test saving the admin
        Admin savedAdmin = adminService.saveAdmin(admin);

        assertNotNull(savedAdmin);
        assertEquals("Admin", savedAdmin.getAdminName());
    }

    @Test
    public void testAddAdmin() {
        // Create a sample admin
        Admin admin = new Admin();
        admin.setAdminName("Admin");
        admin.setPassword("admin@123");

        // Mock the behavior of the adminRepository
        when(adminRepository.findById(anyInt())).thenReturn(Optional.empty());
        when(adminRepository.save(admin)).thenReturn(admin);

        // Test adding the admin
        Admin addedAdmin = adminService.addAdmin(admin);

        assertNotNull(addedAdmin);
        assertEquals("Admin", addedAdmin.getAdminName());
    }


    @Test
    public void testGetAllAdmins() {
        // Create a list of sample admins
        List<Admin> adminList = new ArrayList<>();
        adminList.add(new Admin());
        adminList.add(new Admin());

 
        when(adminRepository.findAll()).thenReturn(adminList);

        // Test getting all admins
        List<Admin> retrievedAdmins = adminService.getAllAdmins();

        assertEquals(2, retrievedAdmins.size());
    }

    @Test
    public void testGetAdminById() {
        Admin admin = new Admin();
        admin.setAdminId(123);
        admin.setAdminName("Admin");
        admin.setPassword("admin@123");

        // Mock the behavior of the adminRepository
        when(adminRepository.findById(123)).thenReturn(Optional.of(admin));

        // Test getting an admin by ID
        Admin retrievedAdmin = adminService.getAdminById(123);

        assertNotNull(retrievedAdmin);
        assertEquals("Admin", retrievedAdmin.getAdminName());
    }

    @Test
    public void testGetAdminByIdNotFound() {
        
        when(adminRepository.findById(anyInt())).thenReturn(Optional.empty());

        Admin retrievedAdmin = adminService.getAdminById(123);

        assertNull(retrievedAdmin);
    }

    @Test
    public void testAdminLoginValidAuth() {
        
        AdminAuth auth = new AdminAuth(123, "admin@123");

        Admin admin = new Admin();
        admin.setAdminId(123);
        admin.setAdminName("Admin");
        admin.setPassword("admin@123");

       
        when(adminRepository.findByAdminIdAndPassword(123, "admin@123")).thenReturn(admin);

        Admin authenticatedAdmin = adminService.adminLogin(auth);

        assertNotNull(authenticatedAdmin);
        assertEquals("Admin", authenticatedAdmin.getAdminName());
    }

    @Test
    public void testAdminLoginInvalidAuth() {
        // Create an invalid AdminAuth object (null values)
        AdminAuth auth = new AdminAuth(null, null);

        when(adminRepository.findByAdminIdAndPassword(anyInt(), anyString())).thenReturn(null);

        Admin authenticatedAdmin = adminService.adminLogin(auth);

        assertNull(authenticatedAdmin);
    }

    @Test
    public void testDeleteAdmin() {
      
        doNothing().when(adminRepository).deleteById(123);
        assertDoesNotThrow(() -> adminService.deleteAdmin(123));
    }
}
