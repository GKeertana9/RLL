package com.example.demo.serviceImpl;

import com.example.demo.entity.Admin;
import com.example.demo.repository.AdminRepository;
import com.example.demo.service.AdminService;
import com.example.demo.utills.AdminAuth;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminServiceImpl implements AdminService {
    private final AdminRepository adminRepository;

    @Autowired
    public AdminServiceImpl(AdminRepository adminRepository) {
        this.adminRepository = adminRepository;
    }

    @Override
    public Admin saveAdmin(Admin admin) {
        return adminRepository.save(admin);
    }

    @Override
    public Admin addAdmin(Admin admin) {
        if (admin == null) {
            throw new IllegalArgumentException("Please provide valid admin data");
        }

        Integer adminId = (int) ((Math.random() * 900) + 100);
        admin.setAdminId(adminId);

        Optional<Admin> checkAdmin = adminRepository.findById(admin.getAdminId());
        if (checkAdmin.isPresent()) {
            throw new IllegalArgumentException("Admin with the same ID already exists");
        } else {
            adminRepository.save(admin);
            return admin;
        }
    }

    @Override
    public List<Admin> getAllAdmins() {
        return adminRepository.findAll();
    }

    @Override
    public Admin getAdminById(int adminId) {
        return adminRepository.findById(adminId).orElse(null);
    }

    @Override
    public Admin adminLogin(AdminAuth auth) {
        if (auth == null || auth.getAdminId() == null || auth.getPassword() == null) {
            return null; // Invalid authentication data
        }

        Admin authenticatedAdmin = adminRepository.findByAdminIdAndPassword(
                auth.getAdminId(),
                auth.getPassword()
        );

        return authenticatedAdmin;
    }

    @Override
    public void deleteAdmin(int adminId) {
        adminRepository.deleteById(adminId);
    }
}
