package com.example.demo.service;

import com.example.demo.entity.Admin;
import com.example.demo.utills.AdminAuth;

import java.util.List;

public interface AdminService {
    Admin saveAdmin(Admin admin);

    Admin addAdmin(Admin admin);

    List<Admin> getAllAdmins();

    Admin getAdminById(int adminId);

    Admin adminLogin(AdminAuth auth);

    void deleteAdmin(int adminId);
}
