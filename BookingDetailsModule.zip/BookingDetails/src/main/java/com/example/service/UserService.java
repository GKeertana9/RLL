package com.example.service;



import com.example.entity.BookingDetails;
import com.example.entity.BusDetails;
import com.example.entity.User;

public interface UserService {
	public User addUser(User user);


	public BookingDetails addBooking(BookingDetails booking, Integer userId, Integer busNumber);

	public void deleteBooking(Integer bookingId, Integer userId);
	
	public BusDetails findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date);



	

}
