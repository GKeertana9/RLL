package com.example;


import com.busManagement.exception.BusDetailsNotFoundException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import static org.mockito.Mockito.when;


import java.util.List;
import java.util.ArrayList;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;


import com.example.entity.BusDetails;
import com.example.Dao.BookingDetailsDao;
import com.example.Dao.BusDetailsDao;
import com.example.Dao.PassengerDao;
import com.example.Dao.UserDao;

//import com.busManagement.exception.PassengerNotFoundException;
import com.example.service.UserService;

@SpringBootTest
public class UserTest {
    @Autowired
    private UserService userService;

    @MockBean
    private UserDao dao;
    @MockBean
    private BusDetailsDao busdao;
    @MockBean
    private PassengerDao passengerdao;
    @MockBean
    private BookingDetailsDao bookingdao;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
  
    @Test
    public void testFindByRouteAndDateValidDetails() {
        String arrivalBusstop = "BusStopA";
        String departureBusstop = "BusStopB";
        String date = "2023-08-10";

        BusDetails bus1 = new BusDetails();
        bus1.setBusNumber(1);
        bus1.setArrivalBusstop(arrivalBusstop);
        bus1.setDepartureBusstop(departureBusstop);
        bus1.setDepartureDate(date);

        List<BusDetails> busList = new ArrayList<>();
        busList.add(bus1);

        when(busdao.findByRouteDate(arrivalBusstop.toLowerCase(), departureBusstop.toLowerCase())).thenReturn(busList);

        BusDetails result = userService.findByRouteAndDate(arrivalBusstop, departureBusstop, date);

        assertEquals(bus1, result);
    }

    @Test
    public void testFindByRouteAndDateInvalidDetails() {
        String arrivalBusstop = "BusStopA";
        String departureBusstop = "BusStopB";
        String date = "2023-08-10";

        List<BusDetails> busList = new ArrayList<>();

        when(busdao.findByRouteDate(arrivalBusstop.toLowerCase(), departureBusstop.toLowerCase())).thenReturn(busList);

        Executable executable = () -> userService.findByRouteAndDate(arrivalBusstop, departureBusstop, date);

        assertThrows(BusDetailsNotFoundException.class, executable);
    }
    
    
    
}
    









