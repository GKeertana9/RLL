package com.example.serviceImpl;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Dao.*;
import com.example.entity.BookingDetails;
import com.example.entity.BusDetails;
import com.example.entity.User;
import com.busManagement.exception.BusDetailsNotFoundException;
import com.busManagement.exception.NullUserException;
import com.busManagement.exception.UserAlreadyExistException;
import com.busManagement.exception.UserDoesnotExistException;
import com.example.service.UserService;


@Service
public class UserServiceImpl implements UserService{

	@Autowired
	UserDao userDao;

	@Autowired
	BusDetailsDao busDao;

	@Autowired
	BookingDetailsDao bookingDao;
	

	@Override
	public User addUser(User user) {

		if (user == null)
			throw new NullUserException("Please Enter Data");
		Integer userId = (int) ((Math.random() * 900) + 100);
		user.setUserId(userId);
		Optional<User> checkUser = userDao.findById(user.getUserId());
		if (checkUser.isPresent())
			throw new UserAlreadyExistException("user already exists");

		userDao.save(user);
		System.out.println("user Added Succesfully");
		return user;

	}

	
	@Override
	public BookingDetails addBooking(BookingDetails booking, Integer userId, Integer busNumber) {
		Optional<User> user = userDao.findById(userId);
		Optional<BusDetails> bus = busDao.findById(busNumber);
		if (!user.isPresent()) {
			throw new UserDoesnotExistException("Sorry! user id not found");
		}
		if (!bus.isPresent()) {
			throw new BusDetailsNotFoundException("Oops!! bus details not found");
		}
		Integer bookingId = (int) ((Math.random() * 9000) + 1000);
		booking.setBookingId(bookingId);
		booking.setOwnerId(userId);
		booking.setBusNumber(busNumber);
		booking.setBookingDate(LocalDate.now().toString());
		booking.setBookingTime(LocalTime.now().toString().substring(0, 5));
		booking.setTotalCost(bus.get().getCost());
		List<BookingDetails> bookingList = user.get().getBookingDetails();
		bookingList.add(booking);
		user.get().setBookingDetails(bookingList);
		return bookingDao.getById(bookingId);
	}
     
	
	//Deleting Booking
	@Override
	public void deleteBooking(Integer bookingId, Integer userId) {
		Optional<User> u = userDao.findById(userId);
		Optional<BookingDetails> bd = bookingDao.findById(bookingId);
		if (!bd.isPresent()) {
			throw new UserDoesnotExistException("Sorry! booking not found");
		}
		if (!u.isPresent()) {
			throw new UserDoesnotExistException("Oops! user id not found");
		}
		User user = u.get();
		List<BookingDetails> bookingList = user.getBookingDetails();
		BookingDetails deleteBooking = null;
		for (BookingDetails b : bookingList) {
			if (b.getBookingId() == bookingId) {
				System.out.println("Sorry! booking id found");
				deleteBooking = b;
			}
		}
		bookingList.remove(deleteBooking);
		user.setBookingDetails(bookingList);
		bookingDao.deleteById(bookingId);
	
	}



    
	
	
	
	

}
