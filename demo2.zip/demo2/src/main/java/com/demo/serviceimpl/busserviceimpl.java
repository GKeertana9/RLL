package com.demo.serviceimpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.entity.BusDetails;
import com.demo.exception.BusDetailsNotFoundException;
import com.demo.exception.NullBusDetailsException;
import com.demo.repository.BusDetailsDao;
import com.demo.service.busservice;

@Service
public class busserviceimpl implements busservice{
	@Autowired
	BusDetailsDao busDao;
	
	@Override
	public BusDetails findByRouteAndDate(String arrivalBusStop, String departureBusStop, String date) {
		List<BusDetails> list = busDao.findByRouteDate(arrivalBusStop.toLowerCase(),
				departureBusStop.toLowerCase());
		for (BusDetails f : list) {
			if (f.getDepartureDate().equals(date)) {
				return f;
			}
		}
		throw new BusDetailsNotFoundException("Sorry! details not found");
	}
    
	
	@Override
	public BusDetails getBusByBusNumber(Integer busNumber) {
		if (busNumber == null) {
			throw new NullBusDetailsException("Please Enter Data");
		}
		Optional<BusDetails> details = busDao.findById(busNumber);
		if (!details.isPresent()) {
			throw new BusDetailsNotFoundException("Oops! No Bus Service Found");
		}
		return details.get();
	}
	@Override
	public BusDetails addBusDetails(BusDetails details) {
		if (details == null) {
			throw new NullBusDetailsException("Please Enter Data");
		}
		Integer busNumber = (int) ((Math.random() * 9000) + 1000);
		details.setBusNumber(busNumber);
		busDao.save(details);
		return details;
	}

}
