package com.demo.service;

import com.demo.entity.BusDetails;

public interface busservice {
public BusDetails findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date);
	
	public BusDetails getBusByBusNumber(Integer busNumber);
	
	public BusDetails addBusDetails(BusDetails details);

	

}
