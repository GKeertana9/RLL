package com.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.entity.BusDetails;
import com.demo.serviceimpl.busserviceimpl;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/user")
public class buscontroller {
	@Autowired
	private busserviceimpl service;
	
	@GetMapping("/findBus/{arrivalBusstop}/{departureBusstop}/{date}")
	public ResponseEntity<BusDetails> findByRouteAndDate(@PathVariable String arrivalBusstop,@PathVariable String departureBusstop,@PathVariable String date){
		BusDetails details = service.findByRouteAndDate(arrivalBusstop, departureBusstop, date);
		return ResponseEntity.ok().body(details);
	}
	
	@GetMapping("/getBusByNumber/{busNumber}")
	public ResponseEntity<BusDetails> getBusByNumber(@PathVariable Integer busNumber){
		BusDetails details = service.getBusByBusNumber(busNumber);
		return ResponseEntity.ok().body(details);
	}
	
	@PostMapping("/addBusDetails")
	public ResponseEntity<BusDetails> addBus(@RequestBody BusDetails busDetails){
		BusDetails details = service.addBusDetails(busDetails);
		return ResponseEntity.ok().body(details);
	}
	
	

}
