package com.example.demo.controller;

import com.example.demo.entity.BusDetails;
import com.example.demo.service.BusDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/busdetails")
public class BusDetailsController {

    private final BusDetailsService busDetailsService;

    @Autowired
    public BusDetailsController(BusDetailsService busDetailsService) {
        this.busDetailsService = busDetailsService;
    }
    @PostMapping("/addBusDetails")
    public ResponseEntity<BusDetails> addBusDetails(@RequestBody BusDetails busDetails) {
        BusDetails addedBus = busDetailsService.addBusDetails(busDetails);

        if (addedBus != null) {
            return ResponseEntity.status(HttpStatus.CREATED).body(addedBus);
        } else {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/findBus/{arrivalBusstop}/{departureBusstop}/{date}")
    public BusDetails findBus(
            @PathVariable String arrivalBusstop,
            @PathVariable String departureBusstop,
            @PathVariable String date) {
        return busDetailsService.findByRouteAndDate(arrivalBusstop, departureBusstop, date);
    }

    @GetMapping("/getBusByNumber/{busNumber}")
    public BusDetails getBusByNumber(@PathVariable Integer busNumber) {
        return busDetailsService.getBusByBusNumber(busNumber);
    }
}
