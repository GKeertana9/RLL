package com.example.demo.service;

import com.example.demo.entity.BusDetails;

public interface BusDetailsService {
    BusDetails findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date);

    BusDetails getBusByBusNumber(Integer busNumber);
    public BusDetails addBusDetails(BusDetails details);
}
