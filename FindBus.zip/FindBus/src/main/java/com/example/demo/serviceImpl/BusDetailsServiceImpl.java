package com.example.demo.serviceImpl;
import com.example.demo.entity.BusDetails;
import com.example.demo.repository.BusDetailsRepository;
import com.example.demo.service.BusDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusDetailsServiceImpl implements BusDetailsService {

    private final BusDetailsRepository busDetailsRepository;

    @Autowired
    public BusDetailsServiceImpl(BusDetailsRepository busDetailsRepository) {
        this.busDetailsRepository = busDetailsRepository;
    }
    @Override
	public BusDetails addBusDetails(BusDetails details) {
		if (details == null) {
			System.out.println("Please Enter Data");
		}
		Integer busNumber = (int) ((Math.random() * 9000) + 1000);
		details.setBusNumber(busNumber);
		busDetailsRepository.save(details);
		return details;
	}
    @Override
    public BusDetails findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date) {
        List<BusDetails> list = busDetailsRepository.findByArrivalBusstopAndDepartureBusstopAndArrivalDate(
                arrivalBusstop.toLowerCase(), departureBusstop.toLowerCase(), date);

        for (BusDetails busDetails : list) {
            if (busDetails.getDepartureDate().equals(date)) {
                return busDetails;
            }
        }

        System.out.println("Sorry! Details not found");
        return null;
    }

    @Override
    public BusDetails getBusByBusNumber(Integer busNumber) {
        return busDetailsRepository.findById(busNumber).orElse(null);
    }
}
