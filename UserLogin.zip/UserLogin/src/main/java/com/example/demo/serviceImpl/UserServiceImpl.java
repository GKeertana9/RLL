package com.example.demo.serviceImpl;


import com.example.demo.utils.*;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
    private final UserRepository userRepository;

    
    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public Optional<User> getUserById(Integer userId) {
        return userRepository.findById(userId);
    }

    @Override
    public User createUser(User user) {
        return userRepository.save(user);
    }
    @Override
	public User userLogin(UserAuth auth) {
		
		if(auth==null) {
			System.out.println("Please Enter User data");
		}
		Optional<User> user = userRepository.findById(auth.getUserId());
		if (user.isPresent()) {
			
			if (user.get().getUserId() == auth.getUserId() && user.get().getPassword().equals(auth.getPassword())) {
				return user.get();
			} else {
				System.out.println("Invalid login ID or Password");
			}
			
		} else {
			System.out.println("Sorry! User not found");
		}
		return null;
	}

   
    @Override
    public User updateUser(Integer userId, User newUserDetails) {
        if (userRepository.existsById(userId)) {
            newUserDetails.setUserId(userId);
            return userRepository.save(newUserDetails);
        } else {
            // Handle the case where the user with the given ID doesn't exist.
            return null;
        }
    }

    @Override
    public void deleteUser(Integer userId) {
        userRepository.deleteById(userId);
    }
}
