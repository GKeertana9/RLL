package com.example.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.bus;

@Repository
public interface  busRepository extends JpaRepository<bus, Integer> {

	@Query("select f from bus f where f.arrivalBusstop = ?1 and f.departureBusstop = ?2") //JPQL 
	public List<bus> findByRouteDate(String sourceBusstop,String destinationBusstop);
	
}

