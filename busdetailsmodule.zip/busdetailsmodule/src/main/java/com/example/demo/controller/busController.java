package com.example.demo.controller;
import java.util.List;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.service.busService;
import com.example.demo.entity.bus;


@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("/bus")
public class busController {



	@Autowired
	 private busService busService;
	
	
	@GetMapping("/getAllBusDetails")
	public ResponseEntity<List<bus>> getAllBusDetails(){
		List<bus> list = busService.getAllBusDetails();
		return ResponseEntity.ok().body(list);
	}
	
	@PostMapping("/addBusDetails")
	public ResponseEntity<bus> addBus(@RequestBody bus busDetails){
		bus details = busService.addBusDetails(busDetails);
		return ResponseEntity.ok().body(details);
	}
	
	@DeleteMapping("/deleteBusDetails/{busNumber}")
	public void deleteBus(@PathVariable Integer busNumber) {
		busService.deleteBus(busNumber);
	}
	
	
	@PostMapping("/updateBusDetails")
	public ResponseEntity<bus> updateBus(@RequestBody bus busDetails){
		bus details = busService.updateBus(busDetails);
		return ResponseEntity.ok().body(details);
	}

	

	@GetMapping("/getBusByNumber/{busNumber}")
	public ResponseEntity<bus> getBusByNumber(@PathVariable Integer busNumber){
		bus details = busService.getBusByBusNumber(busNumber);
		return ResponseEntity.ok().body(details);
	}
	

}

