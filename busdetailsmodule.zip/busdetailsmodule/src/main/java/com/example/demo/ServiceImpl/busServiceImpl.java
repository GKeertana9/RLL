package com.example.demo.ServiceImpl;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.busRepository;
import com.example.demo.entity.bus;
import com.example.demo.service.busService;

import java.util.List;

@Service
public class busServiceImpl implements busService {

    private final busRepository busRepository;

    @Autowired
    public busServiceImpl(busRepository busRepository) {
        this.busRepository = busRepository;
    }

    @Override
    public List<bus> getAllBusDetails() {
        return busRepository.findAll();
    }

    @Override
    public bus addBusDetails(bus details) {
        return busRepository.save(details);
    }

    @Override
    public void deleteBus(Integer busNumber) {
        busRepository.deleteById(busNumber);
    }

    @Override
    public bus updateBus(bus details) {
        return busRepository.save(details);
    }

    @Override
    public bus findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date) {
        // Implement your custom logic to find a bus by route and date
        // You can use busRepository.findByRouteDate(arrivalBusstop, departureBusstop) and filter the result by date
        // Return the matching bus or null if not found
        return null;
    }

    @Override
    public bus getBusByBusNumber(Integer busNumber) {
        // Implement your logic to find a bus by busNumber using busRepository.findById(busNumber)
        // Return the matching bus or null if not found
        return null;
    }

    @Override
    public Double getBusCost(Integer busNumber) {
        // Implement your logic to get the cost of a bus ride by busNumber
        // You can retrieve the bus details and extract the cost from the bus entity
        // Return the cost as a Double or null if not found
        return null;
    }
}
