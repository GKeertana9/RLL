package com.example.demo.service;

import java.util.List;
import com.example.demo.entity.bus;

public interface busService {
	

	public List<bus> getAllBusDetails();

	public bus addBusDetails(bus details);

	public void deleteBus(Integer busNumber);

	public bus updateBus(bus details);

	public bus findByRouteAndDate(String arrivalBusstop, String departureBusstop, String date);
	
	public bus getBusByBusNumber(Integer busNumber);
	
	public Double getBusCost(Integer busNumber);
	

}
